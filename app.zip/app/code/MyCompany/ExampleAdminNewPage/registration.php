    <?php
    \Magento\Framework\Component\ComponentRegistrar::register(
        \Magento\Framework\Component\ComponentRegistrar::MODULE,
        'MyCompany_ExampleAdminNewPage',
        __DIR__
    );
  